import React from "react";
import { Card, CardBody, Divider, Chip, Avatar, Button, Modal, ModalContent, ModalBody, useDisclosure } from "@heroui/react";
import { Icon } from "@iconify/react";
import { Badge } from "@heroui/react";

interface PreviewPanelProps {
  formValues: any;
}

const PreviewPanel: React.FC<PreviewPanelProps> = ({ formValues }) => {
  // Add modal disclosure hook
  const { isOpen, onOpen, onClose } = useDisclosure();
  
  // Add state for image slider
  const [currentSlide, setCurrentSlide] = React.useState(0);
  
  // Extract mainImage separately and enhance feedback about main image
  const { mainImage, media = [], sliderImages = [] } = formValues;
  
  // Determine which image to use as the hero image with clear fallback
  const heroImage = mainImage || (media && media.length > 0 ? media[0] : null);
  const isUsingFallbackImage = !mainImage && media && media.length > 0;
  
  // Extract other properties from formValues
  const { title, description, content, tags, nickname, userImage, emailPrefix, emailDomain } = formValues;
  
  // Create tagArray from tags string
  const tagArray = tags ? tags.split(',').map(tag => tag.trim()).filter(Boolean) : [];
  
  const email = emailPrefix && emailDomain ? `${emailPrefix}@${emailDomain}` : "";
  
  // Enhanced markdown rendering with basic formatting
  const renderMarkdown = (text: string) => {
    if (!text) return null;
    
    // Apply basic markdown formatting
    let formatted = text
      // Headers
      .replace(/^# (.*?)$/gm, '<h1 class="text-3xl font-bold mt-6 mb-4">$1</h1>')
      .replace(/^## (.*?)$/gm, '<h2 class="text-2xl font-bold mt-5 mb-3">$1</h2>')
      .replace(/^### (.*?)$/gm, '<h3 class="text-xl font-bold mt-4 mb-2">$1</h3>')
      // Bold
      .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
      // Italic
      .replace(/\*(.*?)\*/g, '<em>$1</em>')
      // Links
      .replace(/\[(.*?)\]\((.*?)\)/g, '<a href="$2" class="text-primary hover:underline">$1</a>')
      // Lists
      .replace(/^- (.*?)$/gm, '<li>$1</li>')
      // Code
      .replace(/`(.*?)`/g, '<code class="bg-default-100 px-1 rounded">$1</code>')
      // Line breaks
      .replace(/\n/g, '<br />');
    
    // Wrap lists in ul tags
    if (formatted.includes('<li>')) {
      formatted = formatted.replace(/<li>.*?<\/li>/gs, match => `<ul class="list-disc pl-5 my-2">${match}</ul>`);
      // Remove nested ul tags
      formatted = formatted.replace(/<ul class="list-disc pl-5 my-2">(<ul class="list-disc pl-5 my-2">.*?<\/ul>)<\/ul>/g, '$1');
    }
    
    return (
      <div 
        className="markdown-content prose max-w-none" 
        dangerouslySetInnerHTML={{ __html: formatted }}
      />
    );
  };
  
  // Slider navigation functions
  const nextSlide = () => {
    if (sliderImages && sliderImages.length > 0) {
      setCurrentSlide((prev) => (prev + 1) % sliderImages.length);
    }
  };
  
  const prevSlide = () => {
    if (sliderImages && sliderImages.length > 0) {
      setCurrentSlide((prev) => (prev === 0 ? sliderImages.length - 1 : prev - 1));
    }
  };
  
  // Go to specific slide
  const goToSlide = (index: number) => {
    setCurrentSlide(index);
  };

  // Format date for display
  const formatDate = (dateString: string) => {
    if (!dateString) return new Date().toLocaleDateString('en-US', { day: 'numeric', month: 'short', year: 'numeric' });
    return new Date(dateString).toLocaleDateString('en-US', { day: 'numeric', month: 'short', year: 'numeric' });
  };
  
  const currentDate = formatDate(new Date().toISOString());
  
  // Create preview content component to avoid duplication
  const PreviewContent = ({ isModal = false }: { isModal?: boolean }) => (
    <div className={isModal ? "max-w-4xl mx-auto" : ""}>
      {/* Mobile View - Full screen hero image with overlay */}
      <div className={isModal ? "hidden md:block" : "md:hidden"}>
        <div className="relative">
          <img 
            src={heroImage || "https://img.heroui.chat/image/places?w=800&h=600&u=1"}
            alt={title || "블로그 커버 이미지"}
            className="w-full h-[500px] object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-black/30 flex flex-col justify-end p-5">
            <div className="mb-2">
              <div className="flex items-center gap-2">
                <Badge color="primary" variant="flat" className="px-2">Newest Blog</Badge>
                <span className="text-white/80 text-sm">• 4 Min</span>
              </div>
            </div>
            <h1 className="text-3xl font-bold text-white mb-3">
              {title || "블로그 제목이 여기에 표시됩니다"}
            </h1>
            
            {/* Display tags below title on mobile */}
            {tagArray.length > 0 && (
              <div className="flex flex-wrap gap-2 mb-4">
                {tagArray.map((tag: string, index: number) => (
                  <Chip 
                    key={index} 
                    size="sm" 
                    variant="flat" 
                    className="bg-white/20 text-white border-none"
                  >
                    {tag}
                  </Chip>
                ))}
              </div>
            )}
            
            <div className="flex items-center gap-3 mb-4">
              <Avatar 
                src={userImage || "https://img.heroui.chat/image/avatar?w=200&h=200&u=1"}
                name={nickname || "User"}
                className="w-10 h-10 border-2 border-white"
              />
              <div>
                <p className="text-white/80 text-sm mb-0">Written by</p>
                <p className="font-medium text-white">{nickname || "Ariel van Houten"}</p>
              </div>
            </div>
          </div>
        </div>
        
        {/* Mobile Content */}
        <div className="p-5 space-y-6">
          <p className="text-lg leading-relaxed">
            {description || "In the fast-evolving world of home decor, embracing the art of transformation is the key to keeping your living spaces fresh, vibrant, and in tune with the latest trends. At StuffUs, we believe that your home is a canvas waiting to be adorned with innovation and style."}
          </p>
          
          <h2 className="text-2xl font-bold">Introduction</h2>
          
          {content ? (
            renderMarkdown(content)
          ) : (
            <p>
              Software as a Service (SaaS) has transformed the way businesses operate, providing access to a wide range of applications and tools through the internet. Rather than installing software on individual computers or servers, SaaS solutions are hosted in the cloud and accessible through a web browser or mobile app.
            </p>
          )}
          
          {/* Second Image */}
          {(media && media.length > 1) && (
            <div className="my-6">
              <img 
                src={media[1]}
                alt="Blog content image"
                className="w-full h-auto rounded-lg"
              />
            </div>
          )}
          
          <h2 className="text-2xl font-bold">1. Increased Efficiency and Productivity</h2>
          
          {content ? (
            renderMarkdown(content.split('\n\n')[1] || "")
          ) : (
            <p>
              Macrivate offers a range of features that can help your team work more efficiently and productively. With its advanced automation capabilities, your team can automate repetitive tasks, freeing up time for more important tasks. Additionally, the collaboration tools allow for easy communication and project management, reducing the risk of miscommunication and errors.
            </p>
          )}
          
          <h2 className="text-2xl font-bold">2. Improved Customer Satisfaction</h2>
          
          {content ? (
            renderMarkdown(content.split('\n\n')[2] || "")
          ) : (
            <p>
              With Macrivate, you can enhance the customer experience by providing them with a seamless and personalized experience. The customer management tools enable you to keep track of customer interactions, ensuring that you can provide timely and effective support. This can lead to higher customer satisfaction and retention rates.
            </p>
          )}
          
          <h2 className="text-2xl font-bold">3. Enhanced Data Analysis</h2>
          
          {content ? (
            renderMarkdown(content.split('\n\n')[3] || "")
          ) : (
            <p>
              Data is a critical component of any business, and [SaaS product] offers advanced data analytics tools that can help you make better business decisions. The data insights can help you identify patterns and trends, enabling you to make informed decisions that can improve your business performance.
            </p>
          )}
        </div>
      </div>
      
      {/* Desktop View with hero banner and sidebar */}
      <div className={isModal ? "block" : "hidden md:block"}>
        {/* Hero section */}
        <div className="relative h-[300px] mb-10">
          <img 
            src={heroImage || "https://img.heroui.chat/image/places?w=1200&h=600&u=1"}
            alt={title || "Blog cover image"}
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-black/30 flex flex-col justify-end p-6">
            <div className="mb-2">
              <div className="flex items-center gap-2">
                <Badge color="primary" variant="flat" className="px-2">Newest Blog</Badge>
                <span className="text-white/80 text-sm">• 4 Min</span>
              </div>
            </div>
            <h1 className="text-4xl font-bold text-white mb-3">
              {title || "블로그 제목이 여기에 표시됩니다"}
            </h1>
            
            {/* Display tags below title on desktop */}
            {tagArray.length > 0 && (
              <div className="flex flex-wrap gap-2 mb-4">
                {tagArray.map((tag: string, index: number) => (
                  <Chip 
                    key={index} 
                    size="sm" 
                    variant="flat" 
                    className="bg-white/20 text-white border-none"
                  >
                    {tag}
                  </Chip>
                ))}
              </div>
            )}
            
            <div className="flex justify-end">
              <div className="flex items-center gap-3">
                <div className="text-right">
                  <p className="text-sm text-white/80 mb-0">Written by</p>
                  <p className="font-medium text-white">{nickname || "Ariel van Houten"}</p>
                </div>
                <Avatar 
                  src={userImage || "https://img.heroui.chat/image/avatar?w=200&h=200&u=1"}
                  name={nickname || "User"}
                  className="w-10 h-10 border-2 border-white"
                />
              </div>
            </div>
          </div>
        </div>
        
        {/* Main content with sidebar */}
        <div className="flex gap-8">
          {/* Left Sidebar */}
          <div className="w-[120px] flex-shrink-0">
            <div className="space-y-6 sticky top-6">
              <div className="space-y-1">
                <p className="text-sm text-default-500">Date</p>
                <p className="font-medium">{currentDate}</p>
              </div>
              
              <div className="space-y-1">
                <p className="text-sm text-default-500">Facebook</p>
                <p className="font-medium">Stuffsus</p>
              </div>
              
              <div className="space-y-1">
                <p className="text-sm text-default-500">Instagram</p>
                <p className="font-medium">@{nickname ? nickname.toLowerCase().replace(/\s+/g, '_') : "Stuff_sus"}</p>
              </div>
              
              <div className="space-y-1">
                <p className="text-sm text-default-500">LinkedIn</p>
                <p className="font-medium">Stuffsus</p>
              </div>
              
              <div className="space-y-1">
                <p className="text-sm text-default-500">Youtube</p>
                <p className="font-medium">Stuffsus</p>
              </div>
            </div>
          </div>
          
          {/* Main Content */}
          <div className="flex-1">
            {/* Main text content */}
            <div className="prose max-w-none">
              {/* Display tags at the top of content area for better visibility */}
              {tagArray.length > 0 && (
                <div className="flex flex-wrap gap-2 mb-6 not-prose">
                  {tagArray.map((tag: string, index: number) => (
                    <Chip 
                      key={index} 
                      variant="flat" 
                      color="primary" 
                      size="sm"
                      className="rounded-full px-3"
                    >
                      {tag}
                    </Chip>
                  ))}
                </div>
              )}
              
              <p className="text-lg leading-relaxed">
                {description || "In the fast-evolving world of home decor, embracing the art of transformation is the key to keeping your living spaces fresh, vibrant, and in tune with the latest trends. At StuffUs, we believe that your home is a canvas waiting to be adorned with innovation and style."}
              </p>
              
              <h2 className="text-2xl font-bold mt-8 mb-4">Introduction</h2>
              
              {content ? (
                renderMarkdown(content)
              ) : (
                <p>
                  Software as a Service (SaaS) has transformed the way businesses operate, providing access to a wide range of applications and tools through the internet. Rather than installing software on individual computers or servers, SaaS solutions are hosted in the cloud and accessible through a web browser or mobile app.
                </p>
              )}
              
              {/* Second Image */}
              {(media && media.length > 1) && (
                <div className="my-8">
                  <img 
                    src={media[1]}
                    alt="Blog content image"
                    className="w-full h-auto rounded-xl"
                  />
                </div>
              )}
              
              <h2 className="text-2xl font-bold mt-8 mb-4">1. Increased Efficiency and Productivity</h2>
              
              {content ? (
                renderMarkdown(content.split('\n\n')[1] || "")
              ) : (
                <p>
                  Macrivate offers a range of features that can help your team work more efficiently and productively. With its advanced automation capabilities, your team can automate repetitive tasks, freeing up time for more important tasks. Additionally, the collaboration tools allow for easy communication and project management, reducing the risk of miscommunication and errors.
                </p>
              )}
              
              <h2 className="text-2xl font-bold mt-8 mb-4">2. Improved Customer Satisfaction</h2>
              
              {content ? (
                renderMarkdown(content.split('\n\n')[2] || "")
              ) : (
                <p>
                  With Macrivate, you can enhance the customer experience by providing them with a seamless and personalized experience. The customer management tools enable you to keep track of customer interactions, ensuring that you can provide timely and effective support. This can lead to higher customer satisfaction and retention rates.
                </p>
              )}
              
              <h2 className="text-2xl font-bold mt-8 mb-4">3. Enhanced Data Analysis</h2>
              
              {content ? (
                renderMarkdown(content.split('\n\n')[3] || "")
              ) : (
                <p>
                  Data is a critical component of any business, and [SaaS product] offers advanced data analytics tools that can help you make better business decisions. The data insights can help you identify patterns and trends, enabling you to make informed decisions that can improve your business performance.
                </p>
              )}
              
              {/* Image Slider - Added */}
              {sliderImages && sliderImages.length > 0 && (
                <div className="my-8 not-prose">
                  <h3 className="text-xl font-bold mb-4">갤러리</h3>
                  
                  <div className="relative">
                    {/* Main slider image */}
                    <div className="relative aspect-video rounded-lg overflow-hidden bg-default-100">
                      <img 
                        src={sliderImages[currentSlide]} 
                        alt={`슬라이드 이미지 ${currentSlide + 1}`}
                        className="w-full h-full object-cover"
                      />
                      
                      {/* Navigation arrows */}
                      {sliderImages.length > 1 && (
                        <>
                          <Button 
                            isIconOnly
                            variant="flat"
                            className="absolute top-1/2 left-2 -translate-y-1/2 bg-black/30 text-white hover:bg-black/50"
                            onPress={prevSlide}
                          >
                            <Icon icon="lucide:chevron-left" />
                          </Button>
                          <Button 
                            isIconOnly
                            variant="flat"
                            className="absolute top-1/2 right-2 -translate-y-1/2 bg-black/30 text-white hover:bg-black/50"
                            onPress={nextSlide}
                          >
                            <Icon icon="lucide:chevron-right" />
                          </Button>
                        </>
                      )}
                      
                      {/* Slide indicator */}
                      <div className="absolute bottom-2 left-0 right-0 flex justify-center gap-1">
                        {sliderImages.map((_, index) => (
                          <button
                            key={index}
                            onClick={() => goToSlide(index)}
                            className={`w-2 h-2 rounded-full transition-all ${
                              index === currentSlide ? "bg-white" : "bg-white/50"
                            }`}
                          />
                        ))}
                      </div>
                    </div>
                    
                    {/* Thumbnail navigation */}
                    {sliderImages.length > 1 && (
                      <div className="flex overflow-x-auto gap-2 mt-2 pb-2 hide-scrollbar">
                        {sliderImages.map((img, index) => (
                          <button
                            key={index}
                            onClick={() => goToSlide(index)}
                            className={`flex-shrink-0 w-20 h-20 rounded-md overflow-hidden border-2 transition-all ${
                              index === currentSlide ? "border-primary" : "border-transparent"
                            }`}
                          >
                            <img 
                              src={img} 
                              alt={`썸네일 ${index + 1}`} 
                              className="w-full h-full object-cover"
                            />
                          </button>
                        ))}
                      </div>
                    )}
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
  
  return (
    <div className="relative">
      {/* Add feedback about main image */}
      {isUsingFallbackImage && media && media.length > 0 && (
        <div className="bg-warning-50 border border-warning-200 rounded-md p-2 mb-4 flex items-center gap-2">
          <Icon icon="lucide:alert-triangle" className="text-warning flex-shrink-0" />
          <p className="text-warning-700 text-xs">
            메인 이미지가 선택되지 않아 첫 번째 이미지가 자동으로 사용됩니다.
          </p>
        </div>
      )}
      
      {/* Add preview button at the top of content with better visibility */}
      <div className="flex justify-end mb-4">
        <Button
          color="primary"
          variant="flat"
          size="sm"
          onPress={onOpen}
          startContent={<Icon icon="lucide:maximize" />}
          className="shadow-sm text-xs sm:text-sm"
        >
          전체화면 보기
        </Button>
      </div>
      
      {/* Regular preview content */}
      <PreviewContent />
      
      {/* Full screen modal preview */}
      <Modal 
        isOpen={isOpen} 
        onClose={onClose}
        size="full"
        scrollBehavior="inside"
      >
        <ModalContent>
          {(onClose) => (
            <>
              <ModalBody className="p-0">
                <div className="relative">
                  <Button
                    isIconOnly
                    color="default"
                    variant="flat"
                    size="sm"
                    className="absolute top-4 right-4 z-50 bg-white/80 backdrop-blur-sm"
                    onPress={onClose}
                  >
                    <Icon icon="lucide:x" />
                  </Button>
                  <PreviewContent isModal={true} />
                </div>
              </ModalBody>
            </>
          )}
        </ModalContent>
      </Modal>
    </div>
  );
};

export default PreviewPanel;