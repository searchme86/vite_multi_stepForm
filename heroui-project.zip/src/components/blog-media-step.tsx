import React from "react";
import { Button, Card, CardBody, Progress } from "@heroui/react";
import { Icon } from "@iconify/react";
import { useFormContext } from "react-hook-form";
import AccordionField from "./accordion-field";

const BlogMediaStep: React.FC = () => {
  const { setValue, watch } = useFormContext();
  const [dragActive, setDragActive] = React.useState(false);
  const [uploading, setUploading] = React.useState<Record<string, number>>({});
  const [uploadStatus, setUploadStatus] = React.useState<Record<string, 'uploading' | 'success' | 'error'>>({});
  const [selectedFiles, setSelectedFiles] = React.useState<string[]>([]);
  const [sliderImages, setSliderImages] = React.useState<string[]>([]);
  const fileInputRef = React.useRef<HTMLInputElement>(null);
  
  // Fix: Ensure mediaFiles is initialized as an empty array if undefined
  const mediaFiles = Array.isArray(watch("media")) ? watch("media") : [];
  const mainImage = watch("mainImage") || null;
  
  // New utility function to determine file extension icon
  const getFileIcon = (fileName: string) => {
    const extension = fileName.split('.').pop()?.toLowerCase() || '';
    
    switch (extension) {
      case 'jpg':
      case 'jpeg':
        return "lucide:image";
      case 'png':
        return "lucide:image";
      case 'svg':
        return "lucide:file-image";
      case 'gif':
        return "lucide:film";
      default:
        return "lucide:file";
    }
  };
  
  // Add state for pre-selected image (before confirmation)
  const [preSelectedImage, setPreSelectedImage] = React.useState<string | null>(null);
  
  // Updated function to pre-select an image without immediately setting it as main
  const preSelectImage = (imageUrl: string) => {
    setPreSelectedImage(imageUrl);
  };
  
  // New function to confirm the pre-selected image as main image
  const confirmMainImage = () => {
    if (preSelectedImage) {
      setValue("mainImage", preSelectedImage);
      
      // Show success toast
      addToast({
        title: "메인 이미지 설정 완료",
        description: "블로그 메인 페이지에 표시될 대표 이미지가 선택되었습니다.",
        color: "success",
        hideCloseButton: false
      });
    }
  };
  
  // Reset pre-selection
  const cancelPreSelection = () => {
    setPreSelectedImage(null);
  };
  
  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true);
    } else if (e.type === "dragleave") {
      setDragActive(false);
    }
  };
  
  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      handleFiles(e.dataTransfer.files);
    }
  };
  
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      handleFiles(e.target.files);
    }
  };
  
  const handleFiles = (files: FileList) => {
    Array.from(files).forEach((file) => {
      const reader = new FileReader();
      const fileId = `file-${Date.now()}-${Math.random().toString(36).substring(2, 9)}`;
      const fileName = file.name;
      
      // Validate file size (10MB limit)
      if (file.size > 10 * 1024 * 1024) {
        setUploadStatus(prev => ({ ...prev, [fileName]: 'error' }));
        addToast({
          title: "업로드 실패",
          description: `${fileName} 파일이 10MB 제한을 초과합니다.`,
          color: "danger"
        });
        return;
      }
      
      // Set initial upload progress
      setUploading(prev => ({ ...prev, [fileId]: 0 }));
      setUploadStatus(prev => ({ ...prev, [fileName]: 'uploading' }));
      
      reader.onprogress = (event) => {
        if (event.lengthComputable) {
          const progress = Math.round((event.loaded / event.total) * 100);
          setUploading(prev => ({ ...prev, [fileId]: progress }));
        }
      };
      
      reader.onload = (e) => {
        const result = e.target?.result as string;
        
        // Simulate network delay for upload
        setTimeout(() => {
          // Fix: Use functional update to get the latest media array value
          setValue("media", (currentMedia) => {
            const mediaArray = currentMedia || [];
            return [...mediaArray, result];
          });
          setSelectedFiles(prev => [...prev, fileName]);
          setUploadStatus(prev => ({ ...prev, [fileName]: 'success' }));
          
          // Remove from uploading state
          setUploading(prev => {
            const newState = { ...prev };
            delete newState[fileId];
            return newState;
          });
        }, 1500);
      };
      
      reader.readAsDataURL(file);
    });
  };
  
  const removeMedia = (index: number) => {
    const newMedia = [...mediaFiles];
    newMedia.splice(index, 1);
    setValue("media", newMedia);
  };

  const setAsMainImage = (index: number) => {
    setValue("mainImage", mediaFiles[index]);
  };

  const toggleSliderSelection = (imageUrl: string) => {
    setSliderImages(prev => {
      if (prev.includes(imageUrl)) {
        return prev.filter(img => img !== imageUrl);
      } else {
        return [...prev, imageUrl];
      }
    });
  };

  const updateMainImage = (index: number) => {
    const selectedImage = mediaFiles[index];
    setValue("mainImage", selectedImage);
    
    // Show success toast with more descriptive message
    addToast({
      title: "메인 이미지 설정 완료",
      description: "블로그 메인 페이지에 표시될 대표 이미지가 선택되었습니다.",
      color: "success",
      hideCloseButton: false
    });
  };

  React.useEffect(() => {
    setValue("sliderImages", sliderImages);
  }, [sliderImages, setValue]);

  return (
    <div className="space-y-6">
      <div className="bg-default-50 p-4 rounded-lg mb-6">
        <h3 className="text-lg font-medium mb-2">블로그 미디어 입력 안내</h3>
        <p className="text-default-600">
          블로그에 첨부할 이미지를 업로드해주세요. 파일을 드래그하여 업로드하거나 파일 선택 버튼을 클릭하여 
          업로드할 수 있습니다. 지원 형식: JPG, PNG, SVG (최대 10MB).
        </p>
      </div>
      
      {/* REMOVE THIS CONDITION to always show the main image section */}
      <AccordionField 
        title="블로그 메인 이미지 선택" 
        description={mediaFiles.length > 0 ? 
          "블로그 상단에 가장 중요하게 표시될 대표 이미지를 선택하세요." : 
          "이미지를 먼저 업로드한 후 메인 이미지를 선택할 수 있습니다."}
        defaultExpanded={true}
      >
        {mediaFiles.length > 0 ? (
          <div className="space-y-4">
            {/* Existing main image selection UI */}
            {/* ... keep existing main image selection content ... */}
          </div>
        ) : (
          <div className="p-4 bg-default-100 rounded-lg text-center">
            <Icon icon="lucide:image-off" className="text-default-400 w-10 h-10 mx-auto mb-2" />
            <p className="text-default-600">이미지를 업로드하면 메인 이미지를 선택할 수 있습니다.</p>
            <Button 
              color="primary"
              variant="flat"
              size="sm"
              className="mt-3"
              startContent={<Icon icon="lucide:upload" />}
              onPress={() => document.getElementById('media-upload-section')?.scrollIntoView({ behavior: 'smooth' })}
            >
              이미지 업로드하기
            </Button>
          </div>
        )}
      </AccordionField>
      
      {/* REMOVE THIS CONDITION to always show the image preview section */}
      <AccordionField 
        title="업로드된 이미지" 
        description={mediaFiles.length > 0 ? 
          `업로드된 이미지 미리보기 (${mediaFiles.length}개)` : 
          "업로드된 이미지가 여기에 표시됩니다."}
        defaultExpanded={true}
      >
        {mediaFiles.length > 0 ? (
          <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
            {/* Existing image preview grid */}
            {/* ... keep existing image preview content ... */}
          </div>
        ) : (
          <div className="p-4 bg-default-100 rounded-lg text-center">
            <Icon icon="lucide:images" className="text-default-400 w-10 h-10 mx-auto mb-2" />
            <p className="text-default-600">업로드된 이미지가 없습니다.</p>
          </div>
        )}
      </AccordionField>
      
      {/* REMOVE THIS CONDITION to always show the slider section */}
      <AccordionField 
        title="이미지 슬라이더" 
        description="블로그 하단에 표시될 이미지 슬라이더를 위한 이미지들을 선택해주세요."
        defaultExpanded={true}
      >
        <div className="space-y-4">
          {mediaFiles.length > 0 ? (
            <>
              {/* Existing slider selection UI */}
              {/* ... keep existing slider selection content ... */}
            </>
          ) : (
            <div className="p-4 bg-default-100 rounded-lg text-center">
              <Icon icon="lucide:layout-grid" className="text-default-400 w-10 h-10 mx-auto mb-2" />
              <p className="text-default-600">이미지를 업로드하면 슬라이더를 구성할 수 있습니다.</p>
            </div>
          )}
        </div>
      </AccordionField>
      
      {/* Media Upload section - add ID for scroll target */}
      <AccordionField 
        title="미디어 업로드" 
        description="이미지 파일을 업로드해주세요."
        defaultExpanded={true}
        id="media-upload-section"
      >
        <div className="space-y-4">
          <div 
            className={`border-2 border-dashed rounded-lg p-8 text-center ${
              dragActive ? "border-primary bg-primary-50" : "border-default-300"
            }`}
            onDragEnter={handleDrag}
            onDragOver={handleDrag}
            onDragLeave={handleDrag}
            onDrop={handleDrop}
          >
            <div className="flex flex-col items-center gap-2">
              <Icon 
                icon="lucide:upload-cloud" 
                className={`text-4xl ${dragActive ? "text-primary" : "text-default-400"}`} 
              />
              <h3 className="text-lg font-medium">
                {dragActive ? "파일을 놓아주세요" : "클릭하여 파일을 업로드하거나 드래그 앤 드롭하세요"}
              </h3>
              <p className="text-default-500 text-sm mb-4">
                지원 형식: SVG, JPG, PNG (최대 10MB)
              </p>
              <Button
                color="primary"
                variant="flat"
                onPress={() => fileInputRef.current?.click()}
              >
                파일 선택
              </Button>
              <input
                type="file"
                ref={fileInputRef}
                className="hidden"
                accept=".jpg,.jpeg,.png,.svg"
                multiple
                onChange={handleFileChange}
              />
            </div>
          </div>
          
          {/* Uploading Files */}
          {Object.keys(uploading).length > 0 && (
            <div className="space-y-2">
              <h4 className="text-sm font-medium">업로드 중...</h4>
              {Object.entries(uploading).map(([id, progress]) => (
                <div key={id} className="space-y-1">
                  <div className="flex justify-between text-xs">
                    <span>파일 업로드 중</span>
                    <span>{progress}%</span>
                  </div>
                  <Progress value={progress} color="primary" size="sm" />
                </div>
              ))}
            </div>
          )}
          
          {/* Uploaded Files with Status - Enhanced with proper file icons */}
          {selectedFiles.length > 0 && (
            <div className="space-y-2 mt-3">
              <h4 className="text-sm font-medium">업로드된 파일 ({selectedFiles.length})</h4>
              <div className="space-y-2">
                {selectedFiles.map((fileName, index) => (
                  <div 
                    key={index}
                    className={`flex items-center justify-between p-2 rounded-md ${
                      uploadStatus[fileName] === 'error' ? 'bg-danger-50' : 'bg-default-50'
                    }`}
                  >
                    <div className="flex items-center">
                      <Icon 
                        icon={uploadStatus[fileName] === 'error' 
                          ? "lucide:alert-circle" 
                          : getFileIcon(fileName)} 
                        className={uploadStatus[fileName] === 'error' 
                          ? "text-danger mr-2" 
                          : "text-default-600 mr-2"} 
                      />
                      <div>
                        <span className="text-sm">{fileName}</span>
                        {uploadStatus[fileName] === 'error' && (
                          <p className="text-xs text-danger">업로드 실패! 다시 시도해주세요.</p>
                        )}
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      {uploadStatus[fileName] === 'success' && (
                        <Icon icon="lucide:check-circle" className="text-success" />
                      )}
                      <Button
                        isIconOnly
                        size="sm"
                        variant="light"
                        color="danger"
                        onPress={() => {
                          setSelectedFiles(prev => prev.filter((_, i) => i !== index));
                          const newMedia = [...mediaFiles];
                          newMedia.splice(index, 1);
                          setValue("media", newMedia);
                        }}
                      >
                        <Icon icon="lucide:trash-2" />
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </AccordionField>
    </div>
  );
};

export default BlogMediaStep;