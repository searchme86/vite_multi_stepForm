export default function App() {
  return (
    <div className="flex min-h-screen items-center justify-center p-8">
      <p className="text-default-600 text-medium" id="sandbox-message">
        Your AI-generated components will be rendered here
      </p>
    </div>
  );
}
